
import React, { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

/*
 Windows Sense – Final Interactive Prototype (Animated, simplified)
 Surfaces: Dashboard, User Management, Copilot Adapter
 Notes:
  • Notification Center removed (per request)
  • Phase controls removed; single cohesive UX
  • Per-profile hardware stats (RAM / CPU / Storage) shown inside each profile card
*/

type Fix = {
  id: string;
  issue: string;
  component: string;
  action: string;
  status: "Resolved" | "Optimized" | "Suggested";
  timestamp: string;
  category: "Connectivity" | "Driver" | "Performance";
  feedback: null | 1 | -1;
  savedSeconds?: number;
};

export default function App() {
  const [tab, setTab] = useState<"dashboard" | "profiles" | "copilot">("dashboard");
  const [paused, setPaused] = useState(false);
  const [dark, setDark] = useState(false);

  const [fixes, setFixes] = useState<Fix[]>([
    {
      id: "f1",
      issue: "Wi-Fi connection stabilized",
      component: "Intel AX201",
      action: "Adapter reset + DHCP renewal",
      status: "Resolved",
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      category: "Connectivity",
      feedback: null,
      savedSeconds: 90,
    },
    {
      id: "f2",
      issue: "Driver stall cleared (Printer spooler)",
      component: "Print Spooler Service",
      action: "Restarted service, cleared queue",
      status: "Resolved",
      timestamp: new Date(Date.now() - 1000 * 60 * 130).toISOString(),
      category: "Driver",
      feedback: 1,
      savedSeconds: 60,
    },
    {
      id: "f3",
      issue: "Startup disk I/O throttled",
      component: "Windows Search Indexer",
      action: "Throttled to 20% during active hours",
      status: "Optimized",
      timestamp: new Date(Date.now() - 1000 * 60 * 200).toISOString(),
      category: "Performance",
      feedback: null,
      savedSeconds: 120,
    },
  ]);

  // Charts data
  const startupTrend = useMemo(
    () => [
      { d: "Mon", s: 118 },
      { d: "Tue", s: 110 },
      { d: "Wed", s: 102 },
      { d: "Thu", s: 95 },
      { d: "Fri", s: 92 },
      { d: "Sat", s: 90 },
      { d: "Today", s: 87 },
    ],
    []
  );

  const topApps = useMemo(
    () => [
      { app: "POS.exe", min: 210 },
      { app: "Edge", min: 160 },
      { app: "Excel", min: 95 },
      { app: "Teams", min: 80 },
      { app: "PrinterSvc", min: 45 },
    ],
    []
  );

  const totalSaved = fixes.reduce((a, f) => a + (f.savedSeconds || 0), 0);

  function giveFeedback(id: string, v: 1 | -1) {
    setFixes((arr) => arr.map((x) => (x.id === id ? { ...x, feedback: v } : x)));
  }

  // Reusable KPI card
  function KPI({ label, value, sub }: { label: string; value: string; sub?: string }) {
    return (
      <motion.div
        layout
        className="flex-1 rounded-2xl bg-white/90 backdrop-blur px-5 py-4 shadow-sm ring-1 ring-black/5"
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        <div className="text-xs text-gray-500">{label}</div>
        <div className="mt-1 text-3xl font-semibold text-gray-900">{value}</div>
        {sub && <div className="mt-1 text-[11px] text-gray-500">{sub}</div>}
      </motion.div>
    );
  }

  function Dashboard() {
    const todaysFixes = fixes.filter((f) => {
      const dt = new Date(f.timestamp);
      const now = new Date();
      return (
        dt.getDate() === now.getDate() &&
        dt.getMonth() === now.getMonth() &&
        dt.getFullYear() === now.getFullYear()
      );
    });

    return (
      <motion.div layout className="space-y-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
          <KPI label="Startup (today)" value={`${startupTrend[startupTrend.length - 1].s}s`} sub="↓ 26% vs Mon" />
          <KPI label="Auto-fixes (today)" value={`${todaysFixes.length}`} sub="Wi-Fi · Drivers · Perf" />
          <KPI label="Time saved (today)" value={`${Math.round(totalSaved / 60)} min`} sub={`${totalSaved}s cumulative est.`} />
          <KPI label="Reliability Index" value={`8.3 / 10`} sub="steady improvement" />
        </div>

        <motion.div layout className="rounded-2xl bg-white/90 p-5 shadow-sm ring-1 ring-black/5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-semibold">Startup time trend</h2>
          </div>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={startupTrend} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="d" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Line type="monotone" dataKey="s" stroke="#2563eb" strokeWidth={3} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div layout className="rounded-2xl bg-white/90 p-5 shadow-sm ring-1 ring-black/5">
          <h2 className="mb-3 text-base font-semibold">Today’s auto-fixes</h2>
          <ul className="divide-y divide-gray-100">
            {fixes.slice(0, 6).map((f) => (
              <motion.li
                key={f.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-start justify-between gap-4 py-3"
              >
                <div>
                  <div className="text-sm font-medium">
                    {f.issue}
                    <span
                      className={`ml-2 rounded-full px-2 py-0.5 text-xs ${
                        f.category === "Connectivity"
                          ? "bg-indigo-50 text-indigo-700"
                          : f.category === "Driver"
                          ? "bg-violet-50 text-violet-700"
                          : "bg-blue-50 text-blue-700"
                      }`}
                    >
                      {f.category}
                    </span>
                  </div>
                  <div className="text-xs text-gray-600">
                    {new Date(f.timestamp).toLocaleTimeString()} · {f.component}
                  </div>
                  <div className="mt-1 text-xs text-gray-500">Action: {f.action}</div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => giveFeedback(f.id, 1)}
                    className={`rounded-lg px-2 py-1 text-sm ${
                      f.feedback === 1 ? "bg-green-600 text-white" : "bg-green-100 text-green-800"
                    }`}
                    aria-label="Thumbs up"
                  >
                    👍
                  </button>
                  <button
                    onClick={() => giveFeedback(f.id, -1)}
                    className={`rounded-lg px-2 py-1 text-sm ${
                      f.feedback === -1 ? "bg-red-600 text-white" : "bg-red-100 text-red-800"
                    }`}
                    aria-label="Thumbs down"
                  >
                    👎
                  </button>
                </div>
              </motion.li>
            ))}
          </ul>
        </motion.div>
      </motion.div>
    );
  }

  function Profiles() {
    const personas = [
      {
        name: "Gamer",
        desc: "High GPU demand; pause sync & updates during play.",
        apps: [
          { app: "Steam", min: 220 },
          { app: "Discord", min: 140 },
          { app: "Edge", min: 70 },
        ],
        hw: { ramGB: 16, cpu: "6C/12T @ 3.2GHz (boost 4.2)", storage: "512 GB NVMe (free 61%)" },
      },
      {
        name: "Retail – POS",
        desc: "Checkout focus; preload POS & printer drivers.",
        apps: topApps,
        hw: { ramGB: 8, cpu: "4C/8T @ 2.6GHz (boost 3.3)", storage: "256 GB SSD (free 38%)" },
      },
      {
        name: "Browser User",
        desc: "Background tasks OK until resource threshold.",
        apps: [
          { app: "Edge", min: 210 },
          { app: "YouTube", min: 120 },
          { app: "Mail", min: 60 },
        ],
        hw: { ramGB: 8, cpu: "2C/4T @ 2.1GHz (boost 2.8)", storage: "128 GB SSD (free 42%)" },
      },
    ];

    return (
      <motion.div layout className="space-y-6">
        {/* Profiles */}
        <div className="rounded-2xl bg-white/90 p-5 shadow-sm ring-1 ring-black/5">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-base font-semibold">Profiles & Behavior</h2>
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            {personas.map((p) => (
              <motion.div
                key={p.name}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-2xl bg-white p-4 ring-1 ring-gray-200"
              >
                <div className="text-sm font-medium">{p.name}</div>
                <div className="text-xs text-gray-600">{p.desc}</div>

                {/* Per-profile hardware stats */}
                <div className="mt-3 grid grid-cols-3 gap-2 text-[11px] text-gray-700">
                  <div className="rounded-lg bg-gray-50 p-2 ring-1 ring-gray-200">
                    <div className="text-[10px] text-gray-500">RAM</div>
                    <div className="font-medium">{p.hw.ramGB} GB</div>
                  </div>
                  <div className="rounded-lg bg-gray-50 p-2 ring-1 ring-gray-200">
                    <div className="text-[10px] text-gray-500">CPU</div>
                    <div className="font-medium">{p.hw.cpu}</div>
                  </div>
                  <div className="rounded-lg bg-gray-50 p-2 ring-1 ring-gray-200">
                    <div className="text-[10px] text-gray-500">Storage</div>
                    <div className="font-medium">{p.hw.storage}</div>
                  </div>
                </div>

                <div className="mt-3 h-36 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={p.apps}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="app" hide />
                      <YAxis hide />
                      <Tooltip />
                      <Bar dataKey="min" fill="#2563eb" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-2 text-[11px] text-gray-600">Top apps & usage last 7 days</div>
                <div className="mt-3 flex gap-2">
                  <button className="rounded-lg bg-white px-3 py-1.5 text-xs ring-1 ring-gray-200">Edit profile</button>
                  <button className="rounded-lg bg-white px-3 py-1.5 text-xs ring-1 ring-gray-200">Delete</button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Editable user details */}
        <div className="rounded-2xl bg-white/90 p-5 shadow-sm ring-1 ring-black/5">
          <div className="text-sm font-semibold">User Details (editable)</div>
          <div className="mt-2 grid grid-cols-1 gap-3 md:grid-cols-3">
            <input placeholder="Education" className="rounded-xl border border-gray-300 px-3 py-2 text-sm" />
            <input placeholder="Profession" className="rounded-xl border border-gray-300 px-3 py-2 text-sm" />
            <input placeholder="Preferred apps (comma-sep)" className="rounded-xl border border-gray-300 px-3 py-2 text-sm" />
            <input placeholder="Likes / Dislikes" className="rounded-xl border border-gray-300 px-3 py-2 text-sm" />
            <input placeholder="Other Win11 users on device" className="rounded-xl border border-gray-300 px-3 py-2 text-sm" />
          </div>
          <div className="mt-3 flex gap-2">
            <button className="rounded-lg bg-blue-600 px-3 py-1.5 text-sm font-medium text-white">Save</button>
            <button className="rounded-lg bg-white px-3 py-1.5 text-sm ring-1 ring-gray-200">Reset</button>
          </div>
        </div>

        {/* Privacy / federated learning */}
        <div className="rounded-2xl bg-white/90 p-5 shadow-sm ring-1 ring-black/5">
          <div className="mb-2 text-sm font-semibold">Federated Learning & Privacy</div>
          <div className="text-xs text-gray-600">
            Sense learns from similar devices (opt-in). No raw personal data leaves your PC.
          </div>
          <div className="mt-3 flex items-center gap-3 text-sm">
            <label className="text-gray-700">Share learning signals</label>
            <input type="checkbox" defaultChecked className="h-4 w-4" />
            <span className="text-xs text-gray-500">Model v3.1 · Last sync 2h ago</span>
          </div>
        </div>
      </motion.div>
    );
  }

  function Copilot() {
    const [query, setQuery] = useState("");
    const [results, setResults] = useState<any[]>([]);

    function ask() {
      const canned = [
        {
          id: "c1",
          title: "Paused OneDrive during gaming",
          body: "To prevent frame drops, Sense paused sync and deferred updates.",
          cta: "Resume sync",
        },
        {
          id: "c2",
          title: "Create restore point before driver change",
          body: "Snapshot & Rollback ensures safe experimentation.",
          cta: "Create snapshot",
        },
        {
          id: "c3",
          title: "Applied optimization based on similar devices",
          body: "GPU boost applied · Confidence 93% · You can undo anytime.",
          cta: "Explain more",
        },
      ];
      setResults(canned);
    }

    return (
      <motion.div layout className="space-y-6">
        <div className="rounded-2xl bg-white/90 p-5 shadow-sm ring-1 ring-black/5">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-base font-semibold">Copilot · Ask Windows Sense</h2>
            <div className="text-xs text-gray-500">Try: “Why was my sync paused?”</div>
          </div>
          <div className="flex gap-2">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask a question or type an instruction…"
              className="flex-1 rounded-xl border border-gray-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button onClick={ask} className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white">Ask</button>
          </div>
          <AnimatePresence>
            {results.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3"
              >
                {results.map((r) => (
                  <motion.div
                    key={r.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="rounded-2xl bg-white p-4 ring-1 ring-gray-200"
                  >
                    <div className="text-sm font-medium">{r.title}</div>
                    <div className="mt-1 text-xs text-gray-600">{r.body}</div>
                    <button className="mt-2 rounded-lg bg-white px-3 py-1.5 text-sm ring-1 ring-gray-200">{r.cta}</button>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    );
  }

  return (
    <div className={`${dark ? "dark" : ""}`}>
      <div
        className="min-h-screen w-full bg-gradient-to-b from-slate-50 to-slate-100 p-0 text-slate-900 dark:from-slate-900 dark:to-slate-950 dark:text-slate-100"
        style={{ fontFamily: "Segoe UI, system-ui, -apple-system, Roboto, Helvetica, Arial" }}
      >
        {/* App Shell */}
        <div className="mx-auto max-w-6xl px-6 py-6">
          {/* Topbar */}
          <div className="mb-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-xl bg-blue-600" />
              <div>
                <div className="text-lg font-semibold">Windows Sense</div>
                <div className="text-xs text-gray-600 dark:text-gray-300">Adaptive intelligence for Windows 11</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setDark((d) => !d)}
                className="rounded-xl bg-white/80 px-3 py-1.5 text-xs ring-1 ring-gray-200"
              >
                {dark ? "Light" : "Dark"}
              </button>
              <button
                onClick={() => setPaused((p) => !p)}
                className="rounded-xl bg-white/80 px-3 py-1.5 text-xs ring-1 ring-gray-200"
              >
                {paused ? "Resume" : "Pause"}
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="mb-4 flex items-center gap-2">
            {[
              ["dashboard", "Dashboard"],
              ["profiles", "User Management"],
              ["copilot", "Copilot Adapter"],
            ].map(([id, label]) => (
              <button
                key={id}
                onClick={() => setTab(id as "dashboard" | "profiles" | "copilot")}
                className={`rounded-xl px-4 py-2 text-sm ${
                  tab === id ? "bg-blue-600 text-white" : "bg-white/80 ring-1 ring-gray-200"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Content */}
          <AnimatePresence mode="wait">
            {tab === "dashboard" && (
              <motion.div key="dash" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}>
                <Dashboard />
              </motion.div>
            )}
            {tab === "profiles" && (
              <motion.div key="prof" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}>
                <Profiles />
              </motion.div>
            )}
            {tab === "copilot" && (
              <motion.div key="copi" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}>
                <Copilot />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
